
function validate(){
	if(fname()&&lname()&&contact()&&email()&&gen()&&password1()&&confPassword()&&cty()){
		return true;
	}
	else{
		return false;
	}
}


function fname(){
	var firstName = document.getElementById("fName").value;
	var fNamePattern = "^[A-Za-z]+$";
	if(!firstName.match(fNamePattern)){
		document.getElementById("fNameError").innerHTML="First Name Should Be in Alphabets Only";
		document.getElementById("fNameError").style.color="red";
		return false;
	}
	else{
		document.getElementById("fNameError").innerHTML="";
		return true;
	}
}


function lname(){
	var lastName = document.getElementById("lName").value;
	var lNamePattern = "^[A-Za-z]+$";
	if(!lastName.match(lNamePattern)){
		document.getElementById("lNameError").innerHTML="Last Name should be only Alphabets";
		document.getElementById("lNameError").style.color="red";
		return false;
	}
	else{
		document.getElementById("lNameError").innerHTML="";
		return true;
	}
}

function phone(){
	var conNo = document.getElementById("phoneNo").value;
	var conPattern = "^[0-9]{10}$";
	if(!conNo.match(conPattern)){
		document.getElementById("conError").innerHTML="Your No should be of 10 digits only";
		document.getElementById("conError").style.color="red";
		return false;
	}
	else{
		document.getElementById("conError").innerHTML="";
		return true;
	}
}

function email1(){
	var mail = document.getElementById("email").value;
	var mailPattern = "^[a-zA-Z0-9_.]+[@]{1}[a-zA-z]+(.com|.co.in|.in)$";
	if(!mail.match(mailPattern)){
		document.getElementById("emailError").innerHTML="Please Enter Valid Email";
		document.getElementById("emailError").style.color="red";
		return false;
	}
	else{
		document.getElementById("emailError").innerHTML="";
		return true;
	}
}



function gen(){
	var elements = document.getElementsByName("gender");
	var count=0;
	for(var i=0;i<elements.length;i++){
		if(elements[i].checked)
			count++;
	}
	if(count==0){
		document.getElementById("genError").innerHTML="Please Select Your Gender";
		return false;
	}
	else{
		document.getElementById("genError").innerHTML="";
		return true;
	}
}

function password1(){
	var userPassword = document.getElementById("pass").value;
	var passwordPattern = "^[a-zA-Z0-9!@$%&*]{8,}$";
	if(!userPassword.match(passwordPattern)){
		document.getElementById("passError").innerHTML="Please Enter Valid Password";
		document.getElementById("passError").style.color="red";
		return false;
	}
	else{
		document.getElementById("passError").innerHTML="";
		return true;
	}	
}


function confPassword(){
	var pass1 = document.getElementById("pass").value;
	var pass2 = document.getElementById("cpass").value;
	if(pass1==pass2){
		document.getElementById("cPassError").innerHTML="";
		return true;
	}
	else{
		document.getElementById("cPassError").innerHTML="Password Not Match";
		document.getElementById("cPassError").style.color="red";
		return false;
	}
}

function cty(){
	var e = document.getElementsByClassName("cityId");
	var counter = 0;
	for(var i=0;i<e.length;i++){
		if(e[i].selected){
			counter++;
		}
	}	
	if(counter==0){
		document.getElementById("cityError").innerHTML="Please Select A City";
		document.getElementById("cityError").style.color="red";
		return false;
	}
	else{
		document.getElementById("cityError").innerHTML="";
		return true;	
	}
}