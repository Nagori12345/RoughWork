package com.deloitte.testday.services;

import java.util.ArrayList;

import com.deloitte.testday.DAO.UserDAO;
import com.deloitte.testday.model.User;

public class TestdayImpl {

	public void addUser(String fName, String lName, String contact, String eMail, String address, String cityName,
			String password, String userRole) {
		// TODO Auto-generated method stub
		User user = new User();
		user.setUserId(UserDAO.getCounter());
		user.setUserFName(fName);
		user.setUserLName(lName);
		user.setContact(Long.parseLong(contact));
		user.setEmail(eMail);
		user.setAddress(address);
		user.setCity(cityName);
		user.setPassword(password);
		user.setRole(Boolean.parseBoolean(userRole));
		
		UserDAO.addUser(user);
		
	}

	public ArrayList<User> displayBooks() {
		// TODO Auto-generated method stub
		return UserDAO.displayUsers();
	}

	public void signIn(String userEmail, String userPass) {
		// TODO Auto-generated method stub
		UserDAO.checkUser(userEmail, userPass);
	}

}
