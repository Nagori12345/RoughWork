package com.deloitte.testday.services;

import java.util.ArrayList;

import com.deloitte.testday.model.User;

public interface testdayinterface {
	public void addUser(String fName, String lName, String contact, String eMail, String address, String cityName,
			String password, String userRole);
	public ArrayList<User> displayBooks();
	public boolean signIn(String userEmail, String userPass);
	
}
