package com.deloitte.testday.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.deloitte.testday.model.User;

public class UserDAO {
	public static Connection connectToDB() {
		// register the driver
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static int getCounter() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		int count = 101;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select max(userId) from Users");
			while(rs.next()) {
				count=rs.getInt(1);
				count++;
			}
  // throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public static void addUser(User user) {
		// TODO Auto-generated method stub
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Users values(?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, user.getUserId());
			stmt.setString(2, user.getUserFName());
			stmt.setString(3, user.getUserLName());
			stmt.setLong(4, user.getContact());
			stmt.setString(5, user.getEmail());
			stmt.setString(6, user.getAddress());
			stmt.setString(7, user.getCity());
			stmt.setString(8, user.getPassword());
			stmt.setBoolean(9, user.isRole());
			
			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows+" rows affected.");
			conn.close();
			//step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static ArrayList<User> displayUsers() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<User> userArray = new ArrayList<User>();
		
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Users");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt(1));
				user.setUserFName(rs.getString(2));
				user.setUserLName(rs.getString(3));
				user.setContact(rs.getLong(4));
				user.setEmail(rs.getString(5));
				user.setAddress(rs.getString(6));
				user.setCity(rs.getString(7));
				user.setPassword(rs.getString(8));
				user.setRole(rs.getBoolean(9));
				userArray.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userArray;
	}

	public static void checkUser(String userEmail, String userPass) {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
			
			try {
				String checkEmail=null;
				String checkPass=null;
				PreparedStatement stmt = connectToDB().prepareStatement("select email,password from Users where email=? and password=?");
				stmt.setString(1, userEmail);
				stmt.setString(2, userPass);
				ResultSet rs = stmt.executeQuery();		
				int count=0;
				while(rs.next()) {
						count++;
					}
				if(count!=0) {
					System.out.println("login Successful");
					conn.close();
				}
				else
					System.out.println("wrong UserName or Password");
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

}
