package com.deloitte.testday.main;

import java.util.ArrayList;
import java.util.Scanner;
import com.deloitte.testday.model.User;
import com.deloitte.testday.services.TestdayImpl;

public class UserMain {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<User> user = null;
		TestdayImpl testdayimpl = new TestdayImpl();
		while (true) {
			System.out.println("Press 1 for SignUp. 2 for Display all Users. 3 for signIn. and 4 to exit.");
			int option = s.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter First Name");
				String fName=s.next();
				System.out.println("Enter Last Name");
				String lName=s.next();
				System.out.println("Enter contact Name");
				String contact=s.next();
				System.out.println("Enter email Name");
				String eMail=s.next();
				System.out.println("Enter Your Address");
				String address=s.next();
				System.out.println("Enter Your city");
				String cityName=s.next();
				System.out.println("Enter Password");
				String password=s.next();
				System.out.println("Enter Role");
				String userRole=s.next();
				
				testdayimpl.addUser(fName,lName,contact,eMail,address,cityName,password,userRole);
				break;

			case 2:
				user=testdayimpl.displayBooks();
				for(User users:user) {
					System.out.println(users);
				}
				break;

			case 3:
				System.out.println("Enter Your Email");
				String userEmail = s.next();
				System.out.println("Enter Your Password");
				String userPass = s.next();
				
				testdayimpl.signIn(userEmail, userPass);
				break;

			case 4:
				System.exit(0);

			}
		}
	}
}
