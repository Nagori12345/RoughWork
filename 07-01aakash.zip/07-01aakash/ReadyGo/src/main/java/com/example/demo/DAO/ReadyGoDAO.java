package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Cab;
import com.example.demo.model.User;
@Repository
public class ReadyGoDAO {
	public static Connection connectToDB() {
		// register the driver
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public void addCab(Cab cab) {
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Cabs values(?,?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, cab.getCabId());
			stmt.setString(2, cab.getCabCompany());
			stmt.setString(3, cab.getCabModel());
			stmt.setString(4, cab.getCabNumber());
			stmt.setString(5, cab.getCabType());
			stmt.setInt(6, cab.getSitCapacity());
			stmt.setString(7, cab.getYom());
			stmt.setString(8,cab.getCabOwner());
			stmt.setBoolean(9, cab.isCabAvailability());
			stmt.setBoolean(10,cab.isAcStatus());
			
			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows+" rows affected.");
			conn.close();
			//step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<Cab> displayCabs() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<Cab> cabArray = new ArrayList<Cab>();
		
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Cabs");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				Cab cabs = new Cab();
				cabs.setCabId(rs.getInt(1));
				cabs.setCabCompany(rs.getString(2));
				cabs.setCabModel(rs.getString(3));
				cabs.setCabNumber(rs.getString(4));
				cabs.setCabType(rs.getString(5));
				cabs.setSitCapacity(rs.getInt(6));
				cabs.setYom(rs.getString(7));
				cabs.setCabOwner(rs.getString(8));
				cabs.setCabAvailability(rs.getBoolean(9));
				cabs.setAcStatus(rs.getBoolean(9));
				cabArray.add(cabs);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
		return cabArray;
	}

	public String postCab(Cab cab) {
		// TODO Auto-generated method stub
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Cabs values(?,?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, cab.getCabId());
			stmt.setString(2, cab.getCabCompany());
			stmt.setString(3, cab.getCabModel());
			stmt.setString(4, cab.getCabNumber());
			stmt.setString(5, cab.getCabType());
			stmt.setInt(6, cab.getSitCapacity());
			stmt.setString(7, cab.getYom());
			stmt.setString(8,cab.getCabOwner());
			stmt.setBoolean(9, cab.isCabAvailability());
			stmt.setBoolean(10,cab.isAcStatus());
			
			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows+" rows affected.");
			conn.close();
			//step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
		return "data inserted successfully";
	}
}
