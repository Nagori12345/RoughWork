package com.example.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.Cab;
@Service
public class CabService {
	@Autowired
	ReadyGoDAO dao;
	
	
	public void addCab(Cab cab) {
		// TODO Auto-generated method stub
		dao.addCab(cab);
	}


	public ArrayList<Cab> displayCabs() {
		// TODO Auto-generated method stub
		return dao.displayCabs();
	}


	public String postCabs(Cab cab) {
		// TODO Auto-generated method stub
		return dao.postCab(cab);
	}
}
