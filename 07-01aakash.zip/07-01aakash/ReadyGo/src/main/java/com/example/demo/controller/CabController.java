package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Cab;
import com.example.demo.services.CabService;
@Controller
@ResponseBody
public class CabController {
	@Autowired
	CabService service;
	
	@PostMapping("/addCab")
	public void addCab(@RequestBody Cab cab) {
		System.out.println(cab);
		service.addCab(cab);
	}
	
	@GetMapping("/displayCabs")
	public ArrayList<Cab> displayCabs() {
		return service.displayCabs();
	}
	
	@RequestMapping("/form")
	public ModelAndView displayForm() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("cab");
		return modelAndView;
	}
	
	@PostMapping("/submit")
	public ModelAndView myMethod(Cab cab) {
		ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("cab");
			return modelAndView.addObject("result",service.postCabs(cab));
	}
}
