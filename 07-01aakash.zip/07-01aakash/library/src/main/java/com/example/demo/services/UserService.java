package com.example.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.UserDAO;
import com.example.demo.model.User;

@Service
public class UserService {
	@Autowired
	UserDAO dao;
	
//	public User addUser(String fName, String lName, String contact, String eMail, String address, String cityName, String password, String userRole) {
//		// TODO Auto-generated method stub
//		User user = new User();
//		user.setUserId(UserDAO.getCounter());
//		user.setUserFName(fName);
//		user.setUserLName(lName);
//		user.setContact(Long.parseLong(contact));
//		user.setEmail(eMail);
//		user.setAddress(address);
//		user.setCity(cityName);
//		user.setPassword(password);
//		user.setRole(Boolean.parseBoolean(userRole));
//		
//		UserDAO.addUser(user);
//		return user;
//	}
	
	public ArrayList<User> displayUsers() {
		return dao.displayUsers();
	}
	public ArrayList<User> getDetailsThrougnId(String id) {
		return dao.getDetailsThrougnId(id);
	}
	
	public void addUser(User user) {
		// TODO Auto-generated method stub
		dao.addUser(user);
	}
	
	public void deleteThroughId(int id) {
		// TODO Auto-generated method stub
		dao.deleteThroughId(id);
	}
}
