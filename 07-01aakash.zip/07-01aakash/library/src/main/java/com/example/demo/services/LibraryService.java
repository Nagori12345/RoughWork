package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.DAO.LibraryDAO;

@Service
public class LibraryService {
	@Autowired
	LibraryDAO dao;
	public String getMessage() {
		return dao.getMessage();
	}
	public boolean validateUser(String userName, String password) {
		// TODO Auto-generated method stub
		return dao.validateUser(userName,password);
	}
}
