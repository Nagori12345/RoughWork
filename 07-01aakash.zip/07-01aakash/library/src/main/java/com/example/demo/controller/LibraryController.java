package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.services.LibraryService;

@Controller
@ResponseBody
public class LibraryController {
	@Autowired
	LibraryService service;
	@RequestMapping("/display")
	public String getMessage() {
		return service.getMessage();
	}
	
	@RequestMapping("/User")
	public String getUser() {
		return "dfghjhkjhjghjghk";
	}
	
	@RequestMapping("/msg")
	public ModelAndView myMethod() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("myjsp");
		modelAndView.addObject("Aakash",service.getMessage());
		return modelAndView;
	}
	
	@RequestMapping("/form")
	public ModelAndView displayForm() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
//		modelAndView.addObject("Login",service.validateUser());
		return modelAndView;
	}
	
	@GetMapping("/submit")
	public ModelAndView myMethod(@RequestParam("username") String userName,@RequestParam("pass") String password) {
		ModelAndView modelAndView = new ModelAndView();
		if(service.validateUser(userName, password)) {
			modelAndView.setViewName("home");
			modelAndView.addObject("home",userName);
		}
		else {
			modelAndView.setViewName("login");
			modelAndView.addObject("error","Wronge UserName or Password");
		}	
		return modelAndView;	
	}
}
