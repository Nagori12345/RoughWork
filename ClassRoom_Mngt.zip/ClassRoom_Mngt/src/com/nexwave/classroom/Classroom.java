package com.nexwave.classroom;
public class Classroom {
	int classRoomId;
	String clasRoomName;
	int noOfSystems;
	boolean Projector;
	boolean ac;
	String faculty;
	boolean availability;
	
//	static int count=0;
//	static int myId;
//	static String myName;
	
//	public Classroom(){
//		count++;
//	}
	
	
//	static{
//	      myId = 101;
//	      myName = "Aakash Nagori";
//	   }
	
//	static void myMethod()
//    {
//        System.out.println("My Id is : "+myId+"My name is : "+myName);
//    }
	
	
	
	 
	
	public int getClassRoomId() {
		return classRoomId;
	}
	public void setClassRoomId(int classRoomId) {
		this.classRoomId = classRoomId;
	}
	public String getClasRoomName() {
		return clasRoomName;
	}
	public void setClasRoomName(String clasRoomName) {
		this.clasRoomName = clasRoomName;
	}
	public int getNoOfSystems() {
		return noOfSystems;
	}
	public void setNoOfSystems(int noOfSystems) {
		this.noOfSystems = noOfSystems;
	}
	public boolean isProjector() {
		return Projector;
	}
	public void setProjector(boolean projector) {
		Projector = projector;
	}
	public boolean isAc() {
		return ac;
	}
	public void setAc(boolean ac) {
		this.ac = ac;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	@Override
	public String toString() {
		return "Classroom [classRoomId=" + classRoomId + ", clasRoomName=" + clasRoomName + ", noOfSystems="
				+ noOfSystems + ", Projector=" + Projector + ", ac=" + ac + ", faculty=" + faculty + ", availability="
				+ availability + "]";
	}

}
