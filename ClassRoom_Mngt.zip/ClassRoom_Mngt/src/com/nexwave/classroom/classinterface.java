package com.nexwave.classroom;

import java.util.ArrayList;

public interface classinterface {
	public Classroom addRooms(String clsroomId,String clsroomName,String noOfSys,String projector,String ac,String faculty,String available);
	public Classroom searchRooms(String roomId,ArrayList<Classroom> list);
	public ArrayList<Classroom> availabilityOfRooms(String noOfSystems,ArrayList<Classroom> list);
	public void allocateRooms(int noOfSystems);
	public boolean signIn(String userName,String password);
}


