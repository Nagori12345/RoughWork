package com.nexwave.classroom;

import java.util.ArrayList;

public class ClassRoomImpl implements classinterface {
	@Override
	public Classroom addRooms(String clsroomId,String clsroomName,String noOfSys,String projector,String ac,String faculty,String available) {
		// TODO Auto-generated method stub
		Classroom clsroom = new Classroom();
		clsroom.setClassRoomId(Integer.parseInt(clsroomId));
		clsroom.setClasRoomName(clsroomName);
		clsroom.setNoOfSystems(Integer.parseInt(noOfSys));
		clsroom.setFaculty(faculty);
		clsroom.setProjector(Boolean.parseBoolean(projector));
		clsroom.setAc(Boolean.parseBoolean(ac));
		clsroom.setAvailability(Boolean.parseBoolean(available));
		return clsroom;
	}

	@Override
	public Classroom searchRooms(String roomId,ArrayList<Classroom> list) {
		// TODO Auto-generated method stub
		for (Classroom cr : list) {
			if (cr.getClassRoomId() == Integer.parseInt(roomId)) {
				return cr;
			}
		}
		return null;
	}

	@Override
	public ArrayList<Classroom> availabilityOfRooms(String noOfSystems, ArrayList<Classroom> list) {
		// TODO Auto-generated method stub
		ArrayList<Classroom> availableRooms = new ArrayList<Classroom>();
		for(Classroom cr4 : list) {
			if(cr4.getNoOfSystems()>=Integer.parseInt(noOfSystems)) {
				availableRooms.add(cr4);
			}
		}
		return null;
	}

	@Override
	public void allocateRooms(int noOfSystems) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean signIn(String userName, String password) {
		// TODO Auto-generated method stub
		if(userName.equals("Admin") && password.equals("Admin")) {
			return true;
		}
		else
			return false;
	}

	
}
