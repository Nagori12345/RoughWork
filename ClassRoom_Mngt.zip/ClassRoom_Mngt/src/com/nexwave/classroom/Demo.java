package com.nexwave.classroom;
import java.util.*;

public class Demo {
	public static void main(String[] args) {
//		Classroom obj1 = new Classroom();
//		Classroom obj2 = new Classroom();
//		Classroom obj3 = new Classroom();
//		Classroom obj4 = new Classroom();
//		Classroom obj5 = new Classroom();
//		Classroom.myMethod();
//		System.out.println(obj5.count);

		Scanner s = new Scanner(System.in);
		ClassRoomImpl classRoomImplObj = new ClassRoomImpl();
		ArrayList<Classroom> list = new ArrayList<Classroom>();
		while (true) {

			System.out.println("Please Enter Option 1 to Add New Room"
					+ "Option 2 to Search & Display Room Details the Rooms" + "Option 3 to Display all the Rooms"
					+ "Option 4 to allocate the Rooms" + "Option 5 to SignIn" + "Option 7 to exit");
			String option = s.next();

			switch (option) {
			case "1":
				String ClassRoomId="";
				while(true) {
					System.out.println("Enter Class Room Id");
					ClassRoomId = s.next();
					if(Utilities.validateClassroomId(ClassRoomId)) {
						break;
					}
					else 
						continue;				
				}
				
				String clsroomName="";
				while(true) {
					System.out.println("Enter Class Name");
					clsroomName = s.next();
					if(Utilities.validateClassroomName(clsroomName)) {
						break;
					}
					else
						continue;
				}
				
				String noOfSys="";
				while(true) {
					System.out.println("Enter No of Systems");
					noOfSys = s.next();
					if(Utilities.validateNoOfSystems(noOfSys)) {
						break;
					}
					else
						continue;
				}
				

				System.out.println("Enter Projector Availability");
				String projector = s.next();

				System.out.println("Enter AC Availability");
				String ac = s.next();

				System.out.println("Enter Faculty Name");
				String faculty = s.next();

				System.out.println("Enter Rooms Availability");
				String available = s.next();
				
				list.add(classRoomImplObj.addRooms(ClassRoomId,clsroomName,noOfSys,projector,ac,faculty,available));
				break;
				
			case "2":
				System.out.println("Enter Room Id");
				String roomId = s.next();
				System.out.println(classRoomImplObj.searchRooms(roomId, list));
				break;

			case "3":
//				for (Classroom roomObj : list) 
					System.out.println(list);
				break;

			case "4":
				System.out.println("Enter No. of Systems Required");
				String noOfSystems = s.next();
				System.out.println("Enter No. of Rooms Required");
				String noOfRooms = s.next();
				ArrayList<Classroom> availableRooms = classRoomImplObj.availabilityOfRooms(noOfSystems, list);

				if(availableRooms.size()>=Integer.parseInt(noOfRooms)) {
					for (Classroom avlRoom : availableRooms) {
						for(Classroom roomFromMainList : list) {
							if (avlRoom.getClassRoomId() == roomFromMainList.getClassRoomId()) {
								System.out.println("Enter Name of Faculty");
								String fName = s.next();
								roomFromMainList.setFaculty(fName);
								roomFromMainList.setAvailability(false);
								break;
							}
						}		
					}
				}
					System.out.println("No Rooms Available");
				break;
			case "5":
				System.out.println("Enter Your User Name");
				String userName = s.next();
				System.out.println("Enter Your Password");
				String password = s.next();
				
				boolean validateUser=classRoomImplObj.signIn(userName, password);
				if(validateUser) {
					System.out.println("login Successfully");
				}
				else
					System.out.println("Wrong UserName Or Password");
				break;
				
			case "6":
				System.exit(0);
			}
		}
	}
}
