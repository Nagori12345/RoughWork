package com.nexwave.classroom;

public class Utilities {
	public static boolean validateClassroomId(String ClassRoomId){
		String pattern = "^[0-9]{4}$";
		if(ClassRoomId.matches(pattern)) {
			return true;
		}
		else {
			System.out.println("Please Enter Valid Room Id. It Should Be 4 Digit No Only.");
			return false;
		}
	}
	
	public static boolean validateClassroomName(String clsroomName){
		String pattern = "^[a-zA-z]{4}$";
		if(clsroomName.matches(pattern)) {
			return true;
		}
		else {
			System.out.println("Please Enter Room Name In Alphabets Onl");
			return false;
		}
	}
	
	public static boolean validateNoOfSystems(String noOfSys){
		String pattern = "^[1-9]{3}$";
		if(noOfSys.matches(pattern)) {
			return true;
		}
		else {
			System.out.println("Enter No Of Systems Between 1 to 100 only");
			return false;
		}
	}
}
