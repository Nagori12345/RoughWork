package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sound.midi.Soundbank;

import org.springframework.stereotype.Repository;

import com.example.demo.model.User;
@Repository
public class UserDAO {

	public static Connection connectToDB() {
		// register the driver
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static int getCounter() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		int count = 101;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select max(userId) from Users");
			while(rs.next()) {
				count=rs.getInt(1);
				count++;
			}
  // throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public void addUser(User user) {
		// TODO Auto-generated method stub
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Users values(?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, user.getUserId());
			stmt.setString(2, user.getUserFName());
			stmt.setString(3, user.getUserLName());
			stmt.setLong(4, user.getContact());
			stmt.setString(5, user.getEmail());
			stmt.setString(6, user.getAddress());
			stmt.setString(7, user.getCity());
			stmt.setString(8, user.getPassword());
			stmt.setBoolean(9, user.isRole());
			
			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows+" rows affected.");
			conn.close();
			//step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public ArrayList<User> displayUsers() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<User> userArray = new ArrayList<User>();
		
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Users");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt(1));
				user.setUserFName(rs.getString(2));
				user.setUserLName(rs.getString(3));
				user.setContact(rs.getLong(4));
				user.setEmail(rs.getString(5));
				user.setAddress(rs.getString(6));
				user.setCity(rs.getString(7));
				user.setPassword(rs.getString(8));
				user.setRole(rs.getBoolean(9));
				userArray.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userArray;
	}

	public ArrayList<User> getDetailsThrougnId(String id) {
		// TODO Auto-generated method stub
				Connection conn = connectToDB();
				ArrayList<User> userArray = new ArrayList<User>();
				
				try {
					PreparedStatement stmt = connectToDB().prepareStatement("select * from Users where userId=?");
					stmt.setString(1, id);
					ResultSet rs = stmt.executeQuery();
					while(rs.next()) {
						User user = new User();
						user.setUserId(rs.getInt(1));
						user.setUserFName(rs.getString(2));
						user.setUserLName(rs.getString(3));
						user.setContact(rs.getLong(4));
						user.setEmail(rs.getString(5));
						user.setAddress(rs.getString(6));
						user.setCity(rs.getString(7));
						user.setPassword(rs.getString(8));
						user.setRole(rs.getBoolean(9));
						userArray.add(user);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return userArray;
	}
	
	public void deleteThroughId(int id) {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("delete from Users where userId=?");
			stmt.setInt(1, id);
			stmt.executeUpdate();
			System.out.println("1 row deleted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
