package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.DAO.UserDAO;
import com.example.demo.model.User;
import com.example.demo.services.UserService;

@Controller
@ResponseBody
public class UserController {
	@Autowired
	UserService service;
	@RequestMapping("/")
	public ArrayList<User> getMessage() {
		return service.displayUsers();
	}
	
	@RequestMapping("/user")
	public ArrayList<User> getUser(@RequestParam("User Id") String id) {	
	    return service.getDetailsThrougnId(id);
	}
	
	@PostMapping("/addUser")
	public void addUser(@RequestBody User user) {	
//		User user = new User();
//		user.setUserId(UserDAO.getCounter());
//		user.setUserFName(userFName);
//		user.setUserLName(userLName);
//		user.setContact(contact);
//		user.setEmail(eMail);
//		user.setAddress(address);
//		user.setCity(city);
//		user.setPassword(password);
//		user.setRole(role);
		
		System.out.println(user);
		service.addUser(user);
	}
	
	@RequestMapping("/delete")
	public void deleteUser(@RequestParam("UserId") int id) {	
	    service.deleteThroughId(id);
	}
	
}