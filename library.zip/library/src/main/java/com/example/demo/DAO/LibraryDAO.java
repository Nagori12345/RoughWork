package com.example.demo.DAO;

import org.springframework.stereotype.Repository;

@Repository
public class LibraryDAO {
	public String getMessage() {
		return "Hello";
	}
}
