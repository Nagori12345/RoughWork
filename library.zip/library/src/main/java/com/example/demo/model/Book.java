package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Book {
	private int bookId;
	private String bookName;
	private double bookPrice;
	
	Book(){
		System.out.println("Inside Constructor");
	}
	public int getBookId() {
		return bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
}
