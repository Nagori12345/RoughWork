package com.example.demo.services;

import java.util.ArrayList;

import com.example.demo.model.User;

public interface userinterface {
	public void addUser(String fName, String lName, String contact, String eMail, String address, String cityName,
			String password, String userRole);
	public ArrayList<User> displayBooks();
}
