package com.example.demo.DAO;

public class ReadyGoDAO {

}
