package com.example.demo.controller;

public class CabController {

}
