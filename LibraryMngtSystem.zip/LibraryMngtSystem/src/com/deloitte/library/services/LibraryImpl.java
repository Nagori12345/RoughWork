package com.deloitte.library.services;

import java.util.ArrayList;

import com.deloitte.library.dao.BooksDAO;
import com.deloitte.library.exceptions.BookNameException;
import com.deloitte.library.model.Books;
import com.deloitte.library.utilities.Utilities;

public class LibraryImpl implements librarymngtsystem{

	@Override
	public void addBooks(String bookName, Double bookPrice, String bookAuthor) {
		// TODO Auto-generated method stub
		boolean flag=false;
		try {
			Utilities.nameValidation(bookName);
		}
		catch (BookNameException e) {
			// TODO: handle exception
			flag = true;
			System.out.println(e.getMessage());
			
		}
		if(!flag) {
			Books library = new Books();
			library.setBookId(BooksDAO.getCounter());
			library.setBookName(bookName);
			library.setBookPrice(bookPrice);  
			library.setBookAuthor(bookAuthor);
			BooksDAO.addBook(library);
		}
	}

	@Override
	public ArrayList<Books> displayBooks() {
		// TODO Auto-generated method stub
		return BooksDAO.displayBooks();
	}

	public ArrayList<Books> searchBooks(String searchedBoook) {
		// TODO Auto-generated method stub
		return BooksDAO.searchBooks(searchedBoook);
	}

	public void deleteBooks(int deleteBook) {
		// TODO Auto-generated method stub
		BooksDAO.deleteBooks(deleteBook);
	}
	
}
