package com.deloitte.library.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.deloitte.library.exceptions.BookNameException;
import com.deloitte.library.model.Books;
import com.deloitte.library.services.LibraryImpl;
import com.deloitte.library.utilities.Utilities;

public class MainLibrary {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		LibraryImpl libraryimplmain = new LibraryImpl();
		ArrayList<Books> books = null;
//		int bookId = Books.getBookId();
		while (true) {
			System.out.println("Press 1 to Add Book \n2 to Display Books \n3 to search book \n4 to exit \n5 to delete");
			int option = s.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Book Name");
				String bookName = s.next();
				System.out.println("Enter Book Price");
				Double bookPrice = s.nextDouble();
				System.out.println("Enter Author Name");
				String bookAuthor = s.next();
				libraryimplmain.addBooks(bookName, bookPrice, bookAuthor);
				break;

			case 2:
				books=libraryimplmain.displayBooks();
				for(Books book:books) {
					System.out.println(book);
				}
				break;
			case 3:
				System.out.println("Please Enter Book Name");
				String searchedBoook = s.next();
				books=libraryimplmain.searchBooks(searchedBoook);
				for(Books book1:books) {
					System.out.println(book1);
				}
				break;
			
			case 4:
				System.exit(0);
			
			case 5:
				System.out.println("Enter Book Id to Be Deleted ");
				int deleteBook=s.nextInt();
				libraryimplmain.deleteBooks(deleteBook);
				break;
			}
		}
	}
}
