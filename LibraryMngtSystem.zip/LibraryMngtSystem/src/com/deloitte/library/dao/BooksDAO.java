package com.deloitte.library.dao;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.deloitte.library.model.Books;

public class BooksDAO {
	public static Connection connectToDB() {
		// register the driver
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public static void addBook(Books library) {
		// TODO Auto-generated method stub
		System.out.println(library);
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Books values(?,?,?,?)");
			stmt.setInt(1, library.getBookId());
			stmt.setString(2, library.getBookName());
			stmt.setString(3, library.getBookAuthor());
			stmt.setDouble(4, library.getBookPrice()); 
			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows+" rows affected.");
			conn.close();
			//step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static ArrayList<Books> displayBooks() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<Books> dbArray = new ArrayList<Books>();
		
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Books");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				Books book = new Books();
				book.setBookId(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookAuthor(rs.getString(3));
				book.setBookPrice(rs.getDouble(4));
				dbArray.add(book);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbArray;
	}

	public static ArrayList<Books> searchBooks(String searchedBoook) {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<Books> dbBooks = new ArrayList<Books>();
		
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Books");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				if(rs.getString(2).equals(searchedBoook)) {
					Books book = new Books();
					book.setBookId(rs.getInt(1));
					book.setBookName(rs.getString(2));
					book.setBookAuthor(rs.getString(3));
					book.setBookPrice(rs.getDouble(4));
					dbBooks.add(book);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dbBooks;
	}

	public static void deleteBooks(int deleteBook) {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<Books> dbBooks = new ArrayList<Books>();
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("delete from Books where bookId=?");
			stmt.setInt(1, deleteBook);
			int affected = stmt.executeUpdate();
			System.out.println(affected + " row deleted.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}

	public static int getCounter() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		int count = 1001;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select max(bookId) from Books");
			while(rs.next()) {
				count=rs.getInt(1);
				count++;
			}
  // throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	
	

	
}
